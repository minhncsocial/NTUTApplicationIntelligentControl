xp=zeros(1,100);
yp=zeros(1,100);
xc=zeros(1,100);
yc=zeros(1,100);
xh=zeros(1,50);
yh=zeros(1,50);
for i=1:100
    xp(i)=round(rand*10^9)/10^8;
    yp(i)=round(rand*10^9)/10^8;
end
F=F2(xp,yp);
xp=sortff(F,xp);
yp=sortff(F,yp);
F=sort(F);
xh(1)=xp(100);
yh(1)=yp(100);
for j=2:50
    
for i=1:40
    i1=Q1(F,rand);
    i2=Q1(F,rand);
    px1=xp(i1);
    px2=xp(i2);
    py1=yp(i1);
    py2=yp(i2);
    r=rand;
    h1=her1(px1,px2,r);
    h2=her2(px1,px2,r);
    h3=her1(py1,py2,r);
    h4=her2(py1,py2,r);
    while h1<0 | h2<0 | h3<0 | h4<0 | h1>10 | h2>10 | h3>10 | h4>10
        b=rand;
        h1=her1(px1,px2,b);
        h2=her2(px1,px2,b);
        h3=her1(py1,py2,b);
        h4=her2(py1,py2,b);
    end
    xc(2*i-1)=h1;
    xc(2*i)=h2;
    yc(2*i-1)=h3;
    yc(2*i)=h4;
end
for i=81:100
    xc(i)=xp(i);
    yc(i)=yp(i);
end
for i=1:20
    rm=ceil(rand*100);
    x(rm)=round(rand*10^9)/10^8;
    y(rm)=round(rand*10^9)/10^8;
end
xp=xc;
yp=yc;
F=F2(xp,yp);
xp=sortff(F,xp);
yp=sortff(F,yp);
F=sort(F);
xh(j)=xp(100);
yh(j)=yp(100);
end
e1=1:50;
e2=F2(xh(e1),yh(e1));
plot(e1,e2)




