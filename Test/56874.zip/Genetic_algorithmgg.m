
%% Functional Optimization Of Non linear Function using Genetic Algorithm%%
%---------------- By Y.YELLA REDDY, BTech IIT BHUBANESWAR ----------------%

clc;
close all;
clear all;

%------------------------------ Intialization -----------------------------%
x=randint(1,10,[0 1023]);
x1=zeros(1,10);


    
%------------------------- Generating binary code ------------------------%
for i=1:1:10
    x1(i)=x(i);
    for j=1:1:10
        X(i,11-j)=rem(x1(i),2);
        x1(i)=floor(x1(i)/2);
    end
end

x2=(x.*(2*pi))/1024;
x2=x2';

for l=1:1:30
%--------------------- Generating Non Linear Function --------------------%
y=sin(x2);
p=max(y);
Y=sort(y,'descend'); %-------- sorting in descending order

%-------------- Discarding Lower Strata and Starting Crossover------------%

%step1 - swapping X data in the descending order
for i=1:1:10

    for j=1:1:10
    
        if (y(j)==Y(i))
        Z(i,:)=X(j,:);
        end
    
    end
end

%step2 - discard lower 2 data values of Y and Z(Probability = 0.8)
Y=Y(1:8);
Z=Z(1:8,:);
Parents=Z; %Parents

%step3 - starting crossover

n=randperm(8);
m=ceil(rand(1)*10)-1;

for i=1:2:7
    
    CrossoverZ(n(i),1:10)=[Z(n(i),1:m) Z(n(i+1),m+1:10)];
    CrossoverZ(n(i+1),1:10)=[Z(n(i+1),1:m) Z(n(i),m+1:10)];

end
Crossover_Child=CrossoverZ; %crossover


%--------------------------- Starting Mutation ---------------------------%

%Probability =0.1, change any single random value in each to opposite(0to1)
Mutation_Child=Crossover_Child;


o=ceil(rand(1)*10);

for i=1:1:8

    
    if (Crossover_Child(i,o)==0)
        Mutation_Child(i,o)=1;
    else if (Crossover_Child(i,o)==1)
           Mutation_Child(i,o)=0;
        end
    end
    
end

%Parent,Crossover and Mutation childs are made
%Putting them into Fitness Funtion
Final_data=[Parents; Crossover_Child; Mutation_Child];
Final_data_int=zeros(1,24)';

%Converting binary to integers
for i=1:1:24

    for j=1:1:10
    Final_data_int(i)= Final_data_int(i)+power(2,10-j).*Final_data(i,j);
    end
    
end

Final_data_int1=(Final_data_int.*(2*pi))/1024;

Output=sin(Final_data_int1);
Output1=sort(Output,'descend');

for i=1:1:24

    for j=1:1:24
    
        if (Output1(i)==Output(j))
        Final_Output(i,:)=Final_data(j,:);
        end
    
    end
end

Final_Output=Final_Output(1:10,:);

x2=Output1(1:10,:);

maximum(l)=Output1(1);

end


%---------------------- Plotting the final values ------------------------%
maximum=sort(maximum,'ascend');
k=1:1:l;
plot(k,maximum,'--rs','LineWidth',2,...
                'MarkerEdgeColor','k',...
                'MarkerFaceColor','g',...
                'MarkerSize',7)
